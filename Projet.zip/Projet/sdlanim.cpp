/*Les Includes*/

#include "SDL.h"
#include <math.h> /*Pour differentes opération mathématique avancée*/
#include <stdbool.h>

/*Les Defines*/

#define SCREEN_WIDTH  720
#define SCREEN_HEIGHT 540
#define SPRITE_SIZE     32
#define SPRITE_HEIGHT 45*157 /*La hauteur de notre sprite (ici; le lanceur)*/
#define MIDDLE_HEIGHT_ARROW SPRITE_HEIGHT/2 /*Le milieux de notre sprite 5le lanceur), qui equivaut a son milieu d'animation*/
#define BUBBLE_SPRITE_HEIGHT 960
#define PI 3.14159265359 /*la precision est relative mais devrais suffire au projet*/
#define MUR_GAUCHE 200.  /*le mur gauche de notre ecran */
#define MUR_DROIT 520. /*le mur droit de notre ecran*/
#define PLAFOND 31. /*le plafond de notre ecran*/
#define CENTRE_LANCEUR_X (SCREEN_WIDTH/2)-20 /*le centre de l'ecran pour la bulle du lanceur -abcisse-*/
#define CENTRE_LANCEUR_Y 459 /*le centre de l'ecran pour la bulle du lanceur -ordonnée-*/


SDL_Surface *temp, *sprite, *grass;
SDL_Rect rcGrass;

int gameover;
int Temps_animation, Temps_etat;
float Mouvement_x;
SDL_Surface *bubble_blue;
int angle_lanceur,angle_lanceur2, rotation_angle; /*l'angle du lanceur est la position du lanceur au moment t et est comprise entre [-22,22]*/
/*rotation_angle gere l'incrementation de angle_lanceur a chaque mouvement et est toujours de 1 mais par soucis de lisibilité je prefere passer par une variable*/

float directionx, directiony; /*les direction horizontale et verticale de notre bulle calculée par les fonctions éponymes*/

int mouvement; /*booléen, prenant soit 0 soit 1, et gere si la bulle rencontre un obstacle (mur, autre bulle) ou non*/

/* source and destination rectangles */
SDL_Rect rcSrc, rcSprite;
SDL_Surface *screen;

/* Rectangle source et destination pour les sprite de nos bulles*/
SDL_Rect rcSrc_Blue, rcSprite_Blue;


/************/
/*SIGNATURES*/
/************/

float Tir_directionx(int angle_lanceur);/*Fonction gérant le tir de la bulle presente dans le lanceur*/

float Tir_directiony(int angle_lanceur);

void Dessiner_balle_tiree(int directionx, int directiony); /*fonction gerant le dessins de la bulle*/

void Reinitialiser_balle();

/*bool test_contact_balle(param);   fonction gerant si une boule tiree est au contact d une boule deja presente */

/***********/
/*FONCTIONS*/
/***********/


float Tir_directionx(int angle_lanceur)
{
	float Alpha; 
	float directionx_locale;
	
	Alpha = (angle_lanceur*PI)/48; 
	directionx_locale = 0.65*(sin(Alpha));
	return directionx_locale;
}

float Tir_directiony(int angle_lanceur)
{
	float Alpha;
	float directiony_locale;
	
	Alpha = (angle_lanceur*PI)/48;
	directiony_locale = -0.65*(cos(Alpha));
	if(directiony_locale < 0.)
	  {  
	    return directiony_locale * 1.;
	  }
	if(directiony_locale > 0.)
	  {
	    return -directiony_locale * 1.;
	  }
	if(directiony_locale == 0.)
	  {
	    return -1.0;
	  }
}

void Dessiner_balle_tiree(float directionx, float directiony)
{
  double rcSprite_Blue_locale_y;
  double rcSprite_Blue_locale_x;

  rcSprite_Blue_locale_y = rcSprite_Blue.y * 1.;
  rcSprite_Blue_locale_x = rcSprite_Blue.x * 1.;
  while(mouvement == 1)
    {
      SDL_UpdateRect(screen, 0, 0, 0, 0);
      rcSprite_Blue_locale_y += directiony;   /*on augmente la hauteur de notre balle -en fonction de direction y-*/
      
      if(rcSprite_Blue_locale_y == PLAFOND || rcSprite_Blue_locale_y < PLAFOND) /*on verifie que l'on ne touche pas le plafond*/
	{
	  /*remplir de maniere a stopper le mouvement de la balle si c'est le cas -ajouter une variable ?-*/
	  mouvement = 0;
	  rcSprite_Blue_locale_y = PLAFOND;
	}
      /*ajouter une partie verifiant si l'on a toucher une autre bulle*/
      
      /*on deplace la bulle vers la droite ou la gauche -en fonction de directionx- */
      rcSprite_Blue_locale_x += directionx *1.;
     
      /*si on touche l'un des mur -peu importe lequel- on inverse directionx*/
      if((rcSprite_Blue_locale_x <= (MUR_GAUCHE))||(rcSprite_Blue_locale_x >= (MUR_DROIT-40)))
	{
	  directionx = -directionx *1.;
	  rcSprite_Blue_locale_x += directionx *1.;
	 
	}
      SDL_UpdateRect(screen, 0, 0, 0, 0);
      SDL_FillRect(screen,NULL,SDL_MapRGB(screen->format, 0,0,0));/*on nettoie l'ecran*/
      SDL_BlitSurface(grass, NULL, screen, NULL);/*on redessine l'ecran etape par etape 1: le background*/
      SDL_BlitSurface(sprite,&rcSrc, screen, &rcSprite);/*on redessine le lanceur*/
      rcSprite_Blue.x = rcSprite_Blue_locale_x;
      rcSprite_Blue.y = rcSprite_Blue_locale_y;
      SDL_BlitSurface(bubble_blue, &rcSrc_Blue, screen, &rcSprite_Blue);/*on dessine la bulle a chaque passage de la boucle*/
     
    }
  /*il peut etre nescessaire de re-verifier si l'on touche une bulle*/

}

void Reinitialier_balle()
{
  
}



void HandleEvent(SDL_Event event)
{
	switch (event.type) {
		/* close button clicked */
		case SDL_QUIT:
			gameover = 1;
			break;
			
		/* handle the keyboard */
		case SDL_KEYDOWN:
			switch (event.key.keysym.sym) {
				case SDLK_SPACE:
				  if((rcSprite_Blue.x == CENTRE_LANCEUR_X)&&(rcSprite_Blue.y == CENTRE_LANCEUR_Y))
				    {
				      directionx = Tir_directionx(angle_lanceur);
				      directiony = Tir_directiony(angle_lanceur);
				      mouvement = 1;
				      Dessiner_balle_tiree(directionx, directiony);
				    }
				  else
				    {
				      rcSprite_Blue.x = CENTRE_LANCEUR_X;
				      rcSprite_Blue.y = CENTRE_LANCEUR_Y;
				    }
				  break;
				case SDLK_q:
				  gameover = 1;
				  break;
				case SDLK_LEFT:
				  /*Si on est pas en fin d'animation (vers la gauche), alors on avance l'animation vers la gauche*/
				  /*ce qui revient a "baisser" dans le sprite*/
				  /*on change aussi l'angle du lanceur*/
					if ( rcSrc.y > 0 )
					{
						rcSrc.y -= 157;
						angle_lanceur -= rotation_angle;
					}		
					break;
				case SDLK_RIGHT:
				  if ( rcSrc.y < SPRITE_HEIGHT-157)
				  {	
					  rcSrc.y = rcSrc.y+157;
					  angle_lanceur += rotation_angle;
				  }	
					break;
				case SDLK_UP: 
				  /*la fleche haut montera la fleche vers le centre de l'ecran (a la verticale)*/
				  if (rcSrc.y < (MIDDLE_HEIGHT_ARROW)-157)
				  {
				     rcSrc.y = rcSrc.y+157;
					 angle_lanceur += rotation_angle;
				  }
				  else if (rcSrc.y >(MIDDLE_HEIGHT_ARROW))
				  {
					rcSrc.y = rcSrc.y - 157;
					angle_lanceur -= rotation_angle;
				  }
				  break;
				case SDLK_DOWN:
				  /*La fleche bas va faire descendre la fleche jusque l'horizontal (gauche, ou droite dependant de la position de  "depart" de notre fleche*/
				  if ((rcSrc.y < (MIDDLE_HEIGHT_ARROW)) && rcSrc.y > 0)
				  {
					  rcSrc.y = rcSrc.y-157;
					  angle_lanceur -= rotation_angle;
				  }
				  else if ((rcSrc.y <(SPRITE_HEIGHT-157)) && rcSrc.y != 0)
				  {
					  rcSrc.y = rcSrc.y + 157;
					  angle_lanceur += rotation_angle;
				  }
				  break;

			default: break;
			}
			break;
	default: break;
	}
}

int main(int argc, char* argv[])
{
	int colorkey, colorkey_black;
	int i;
	int tempsPrecedent, tempsActuel; /*Les Variables ci sont utilisée avec les fonctions gérant le temps réel; ex : SDL_GetTicks*/
	/*Initialisation des differentes Variable*/
	angle_lanceur = -22;
	rotation_angle = 1;

	/* initialize SDL */
	SDL_Init(SDL_INIT_VIDEO);

	/* set the title bar */
	SDL_WM_SetCaption("SDL Animation", "SDL Animation");

	/* create window */
	screen = SDL_SetVideoMode(SCREEN_WIDTH, SCREEN_HEIGHT, 0, 0);

	/* set keyboard repeat */
	SDL_EnableKeyRepeat(70, 70);

	/* load sprite */
	temp   = SDL_LoadBMP("sprite.bmp");
	sprite = SDL_DisplayFormat(temp);
	SDL_FreeSurface(temp);

	/* load second sprites (bobble - Blue) */
	/*ce sprite vient de spriters-ressource.com, et a été publié par John2k4*/
	temp = SDL_LoadBMP("bub_blue.bmp");
	bubble_blue = SDL_DisplayFormat(temp);
	SDL_FreeSurface(temp);

	/* setup sprite colorkey and turn on RLE */
	colorkey = SDL_MapRGB(screen->format, 255, 0, 255);
	colorkey_black = SDL_MapRGB(screen->format, 255, 0, 255);
	SDL_SetColorKey(sprite, SDL_SRCCOLORKEY | SDL_RLEACCEL, colorkey);
	SDL_SetColorKey(bubble_blue, SDL_SRCCOLORKEY | SDL_RLEACCEL, colorkey_black);
	/* load Background */
	temp  = SDL_LoadBMP("grass.bmp");
	grass = SDL_DisplayFormat(temp);
	SDL_FreeSurface(temp);

	/* set sprite position */
	rcSprite.x = 267;
	rcSprite.y = 385;

	/* set animation frame */
	rcSrc.x = 0;
	rcSrc.y = 0;
	rcSrc.w = 187; /*Largeur de notre sprite (le lanceur)*/
	rcSrc.h = 157; /*Hauteur de notre sprite (le lanceur)*/

	/* Sprite position : Bubble (Bleu) */
	rcSprite_Blue.x = CENTRE_LANCEUR_X;
	rcSprite_Blue.y = CENTRE_LANCEUR_Y;

	/*Sprite animation frame : Bubble (Bleu)*/
	rcSrc_Blue.x = 0;
	rcSrc_Blue.y = 0;
	rcSrc_Blue.w = 40; /*Largeur de notre bulle (Bleu)*/
	rcSrc_Blue.h = 40; /*Hauteur de notre bulle (Bleu)*/

	gameover = 0;

	/* message pump */
	while (!gameover)
	{
		SDL_Event event;
		
		/* look for an event */
		if (SDL_PollEvent(&event)) {
			HandleEvent(event);
		}

		/* collide with edges of screen */
		if (rcSprite.x <= 0)
			rcSprite.x = 0;
		if (rcSprite.x >= SCREEN_WIDTH - SPRITE_SIZE) 
			rcSprite.x = SCREEN_WIDTH - SPRITE_SIZE;

		if (rcSprite.y <= 0)
			rcSprite.y = 0;
		if (rcSprite.y >= SCREEN_HEIGHT - SPRITE_SIZE) 
			rcSprite.y = SCREEN_HEIGHT - SPRITE_SIZE;

		/* draw the grass */

		SDL_BlitSurface(grass, NULL, screen, NULL);
			
		

		/* draw the sprite */
		SDL_BlitSurface(sprite,&rcSrc, screen, &rcSprite);

		/* dessiner Sprite : Bubble (Bleu) */
		SDL_BlitSurface(bubble_blue, &rcSrc_Blue, screen, &rcSprite_Blue);

		/* update the screen */
		/*SDL_UpdateRect(screen, 0, 0, 0, 0);*/
		i = 0;
		tempsPrecedent = 0;
		tempsActuel = SDL_GetTicks(); /*on donne a notre "tempsActuel" la valeur en milliseconde du temps ecoulés depuis le début du niveau (ici notre programme)*/
		if(tempsActuel - tempsPrecedent > 1000) /*gestion de l'animation de la bulle bleue (penser a placer cela en fonction/procedure)*/
		  {
		    SDL_UpdateRect(screen, 0, 0, 0, 0);
		    if (rcSrc_Blue.y < BUBBLE_SPRITE_HEIGHT - 40)
		      {
			rcSrc_Blue.y += 40;
		      }
		    else
		      {
			rcSrc_Blue.y = 0;
		      }
		    tempsPrecedent=tempsActuel;
		    }
		
		
	}

	/* clean up */
	SDL_FreeSurface(sprite);
	SDL_FreeSurface(grass);
	SDL_Quit();

	return 0;
}
